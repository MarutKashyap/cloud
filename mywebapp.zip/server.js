const express = require("express");
const path = require("path");

const app = express();
const port = process.env.PORT || 8080;

// Set EJS as the template engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Routes
app.get("/", (req, res) => {
  res.render("index", { message: "🚀 Hello from Node.js on AWS Elastic Beanstalk!" });
});

// Start server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
